#include "GameStates.hpp"

GameStates CURRENT_GAME_STATE = GameStates::WELCOME;
